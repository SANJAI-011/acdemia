export interface User {
	regNumber: string;
	year: number;
	name: string;
	batch: string;
	mobile: string;
	program: string;
	department: string;
	section: string;
	semester: string;
	classRoom: string;
}

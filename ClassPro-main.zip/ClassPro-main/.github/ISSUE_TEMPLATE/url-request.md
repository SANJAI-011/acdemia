---
name: URL Request
about: Requesting URL to be added in "Useful Links"
title: "[URL]: Request new URL"
labels: URL
assignees: ''

---

- [ ] Is this relatable to SRM students
- [ ] is this safe and valid

URL: `<url>`

import Academia from "./home/page";

export default function Index() {
	return <Academia />;
}

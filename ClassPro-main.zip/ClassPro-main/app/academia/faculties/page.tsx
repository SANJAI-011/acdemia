import React from "react";
import FacultyPage from "./Faculties";

export default async function Faculties() {
	return <FacultyPage />;
}

import React from "react";
import Library from "@/app/academia/library/LibraryHome";

export default async function Docupro() {
	return <Library />;
}
